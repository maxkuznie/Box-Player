package com.example.boxplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Insets
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Original set-top-box style media player: navy gradient, left menu,
 * numbered file list, colour-button hint bar and an on-screen info banner.
 */
class MainActivity : Activity() {

    private data class Item(val uri: android.net.Uri, val title: String, val durationMs: Long)

    private val navy = Color.parseColor("#0A1B3D")
    private val blue = Color.parseColor("#17407A")
    private val orange = Color.parseColor("#FF8A00")
    private val dim = Color.parseColor("#9FB3D1")
    private val perms = arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)

    private val items = ArrayList<Item>()
    private val fileAdapter = FileAdapter()
    private val ui = Handler(Looper.getMainLooper())
    private var showVideo = true
    private var bars: Insets = Insets.NONE

    private lateinit var mainUi: LinearLayout
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var menuVideo: TextView
    private lateinit var menuMusic: TextView

    private lateinit var playerLayer: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var banner: LinearLayout
    private lateinit var bannerTitle: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var playBtn: ImageView
    private var player: ExoPlayer? = null
    private var videoRatio = 0f

    private val hideBanner = Runnable { banner.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            player?.let { p ->
                val d = p.duration
                if (d != C.TIME_UNSET && d > 0) {
                    seek.max = d.toInt()
                    seek.progress = p.currentPosition.toInt()
                    timeText.text = "${fmt(p.currentPosition)} / ${fmt(d)}"
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun match() = FrameLayout.LayoutParams(MATCH, MATCH)

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%02d:%02d".format(s / 60, s % 60)
    }

    private fun pill() = GradientDrawable().apply {
        setColor(orange)
        cornerRadius = dp(6).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(buildMain(), match())
        root.addView(buildPlayer(), match())
        root.setOnApplyWindowInsetsListener { _, insets ->
            bars = insets.getInsets(WindowInsets.Type.systemBars())
            applyBars()
            insets
        }
        setContentView(root)
        styleMenu()
        refresh()
    }

    private fun applyBars() {
        mainUi.setPadding(bars.left + dp(24), bars.top + dp(16), bars.right + dp(24), bars.bottom + dp(12))
        banner.setPadding(bars.left + dp(24), dp(14), bars.right + dp(24), bars.bottom + dp(14))
    }

    // ---------- Home screen ----------

    private fun buildMain(): LinearLayout {
        mainUi = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(navy, blue))
        }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("BOX PLAYER", 22f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(TextClock(this).apply {
            format12Hour = "EEE dd.MM  HH:mm"
            format24Hour = "EEE dd.MM  HH:mm"
            textSize = 16f
            setTextColor(dim)
        })
        mainUi.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        menuVideo = menuItem("Videos") { select(true) }
        menuMusic = menuItem("Music") { select(false) }
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(menuVideo)
            addView(menuMusic)
        }

        empty = label("No files to show.\nMake sure media access is allowed.", 16f, dim).apply {
            gravity = Gravity.CENTER
        }
        list = ListView(this).apply {
            divider = null
            setSelector(GradientDrawable().apply {
                setColor(0x55FF8A00)
                cornerRadius = dp(6).toFloat()
            })
            adapter = fileAdapter
            emptyView = empty
            setOnItemClickListener { _, _, pos, _ -> play(pos) }
        }
        val right = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0x33000000)
                cornerRadius = dp(10).toFloat()
            }
            addView(list, match())
            addView(empty, match())
        }

        val body = LinearLayout(this).apply { setPadding(0, dp(16), 0, dp(8)) }
        body.addView(menu, LinearLayout.LayoutParams(dp(130), MATCH))
        body.addView(right, LinearLayout.LayoutParams(0, MATCH, 1f))
        mainUi.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val hints = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hints.addView(hint("#E53935", "Videos") { select(true) })
        hints.addView(hint("#43A047", "Music") { select(false) })
        hints.addView(hint("#FDD835", "Refresh") { refresh() })
        hints.addView(hint("#1E88E5", "Play all") { if (items.isNotEmpty()) play(0) })
        mainUi.addView(hints, LinearLayout.LayoutParams(MATCH, WRAP))
        return mainUi
    }

    private fun menuItem(t: String, onClick: () -> Unit) = label(t, 18f, Color.WHITE).apply {
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun hint(color: String, text: String, onClick: () -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(6), dp(22), dp(6))
        addView(View(context).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(color))
            }
        }, LinearLayout.LayoutParams(dp(14), dp(14)).apply { rightMargin = dp(8) })
        addView(label(text, 14f, Color.WHITE))
        setOnClickListener { onClick() }
    }

    private fun styleMenu() {
        for ((v, on) in listOf(menuVideo to showVideo, menuMusic to !showVideo)) {
            v.background = if (on) pill() else null
            v.setTextColor(if (on) Color.BLACK else Color.WHITE)
        }
    }

    private fun select(video: Boolean) {
        showVideo = video
        styleMenu()
        refresh()
    }

    // ---------- Library ----------

    private fun hasAccess() = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun refresh() {
        if (!hasAccess()) {
            requestPermissions(perms, 1)
            return
        }
        val video = showVideo
        Thread {
            val found = query(video)
            runOnUiThread {
                items.clear()
                items.addAll(found)
                fileAdapter.notifyDataSetChanged()
            }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAccess()) refresh()
    }

    private fun query(video: Boolean): List<Item> {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val nameCol = if (video) MediaStore.Video.Media.DISPLAY_NAME else MediaStore.Audio.Media.TITLE
        val where = if (video) null else "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val out = ArrayList<Item>()
        contentResolver.query(
            base,
            arrayOf(MediaStore.MediaColumns._ID, nameCol, MediaStore.MediaColumns.DURATION),
            where, null, "$nameCol COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val raw = c.getString(1) ?: "Untitled"
                val title = if (video) raw.substringBeforeLast('.') else raw
                out.add(Item(ContentUris.withAppendedId(base, c.getLong(0)), title, c.getLong(2)))
            }
        }
        return out
    }

    private inner class FileAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                addView(label("", 15f, orange, true), LinearLayout.LayoutParams(dp(48), WRAP))
                addView(label("", 17f, Color.WHITE).apply {
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(label("", 14f, dim))
            }
            val item = items[position]
            (row.getChildAt(0) as TextView).text = "%03d".format(position + 1)
            (row.getChildAt(1) as TextView).text = item.title
            (row.getChildAt(2) as TextView).text = fmt(item.durationMs)
            return row
        }
    }

    // ---------- Player ----------

    private fun buildPlayer(): FrameLayout {
        playerLayer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            isClickable = true
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitVideo() }
        }
        surface = SurfaceView(this)
        playerLayer.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        playerLayer.addView(View(this).apply { setOnClickListener { toggleBanner() } }, match())

        bannerTitle = label("", 20f, Color.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        timeText = label("00:00 / 00:00", 14f, dim)
        seek = SeekBar(this).apply {
            progressTintList = ColorStateList.valueOf(orange)
            thumbTintList = ColorStateList.valueOf(orange)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) player?.seekTo(progress.toLong())
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        playBtn = ctrl(android.R.drawable.ic_media_play) {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        val seekRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        seekRow.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        seekRow.addView(timeText)
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(ctrl(android.R.drawable.ic_media_previous) { player?.seekToPreviousMediaItem() })
            addView(ctrl(android.R.drawable.ic_media_rew) { player?.let { it.seekTo(maxOf(0L, it.currentPosition - 10_000)) } })
            addView(playBtn)
            addView(ctrl(android.R.drawable.ic_media_ff) { player?.let { it.seekTo(it.currentPosition + 10_000) } })
            addView(ctrl(android.R.drawable.ic_media_next) { player?.seekToNextMediaItem() })
        }
        banner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xEE0A1B3D.toInt()))
            visibility = View.GONE
            addView(bannerTitle)
            addView(seekRow)
            addView(controls)
        }
        playerLayer.addView(banner, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        return playerLayer
    }

    private fun ctrl(res: Int, onClick: () -> Unit) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(dp(8), 0, dp(8), 0) }
        setOnClickListener {
            onClick()
            showBanner()
        }
    }

    private fun play(index: Int) {
        val p = player ?: ExoPlayer.Builder(this).build().also { np ->
            np.setVideoSurfaceView(surface)
            np.addListener(object : Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = titleFor(np.currentMediaItemIndex)
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playBtn.setImageResource(if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
                }
                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    videoRatio = if (videoSize.height == 0) 0f
                    else videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
                    fitVideo()
                }
            })
            player = np
        }
        surface.visibility = if (showVideo) View.VISIBLE else View.INVISIBLE
        p.setMediaItems(items.map { MediaItem.fromUri(it.uri) }, index, 0L)
        p.prepare()
        p.play()
        playerLayer.visibility = View.VISIBLE
        window.insetsController?.apply {
            hide(WindowInsets.Type.systemBars())
            systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        titleFor(index)
        showBanner()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    private fun titleFor(i: Int) {
        bannerTitle.text = items.getOrNull(i)?.let { "%03d   %s".format(i + 1, it.title) } ?: ""
    }

    private fun fitVideo() {
        val cw = playerLayer.width
        val ch = playerLayer.height
        if (videoRatio <= 0f || cw == 0 || ch == 0) return
        val w: Int
        val h: Int
        if (cw.toFloat() / ch > videoRatio) {
            h = ch
            w = (ch * videoRatio).toInt()
        } else {
            w = cw
            h = (cw / videoRatio).toInt()
        }
        surface.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    private fun showBanner() {
        banner.visibility = View.VISIBLE
        ui.removeCallbacks(hideBanner)
        if (showVideo) ui.postDelayed(hideBanner, 5000)
    }

    private fun toggleBanner() {
        if (banner.visibility == View.VISIBLE) {
            ui.removeCallbacks(hideBanner)
            banner.visibility = View.GONE
        } else showBanner()
    }

    private fun closePlayer() {
        ui.removeCallbacks(tick)
        ui.removeCallbacks(hideBanner)
        player?.release()
        player = null
        playerLayer.visibility = View.GONE
        window.insetsController?.show(WindowInsets.Type.systemBars())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (playerLayer.visibility == View.VISIBLE) closePlayer() else super.onBackPressed()
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        player?.release()
        player = null
    }
}
