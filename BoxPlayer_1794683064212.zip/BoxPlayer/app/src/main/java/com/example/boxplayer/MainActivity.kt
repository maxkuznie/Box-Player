package com.example.boxplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Insets
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Original set-top-box style media player: navy gradient, left menu,
 * numbered file list, colour-button hint bar and an on-screen info banner.
 */
class MainActivity : Activity() {

    private data class Item(
        val uri: android.net.Uri,
        val title: String,
        val durationMs: Long,
        val line2: String,
        val line3: String
    )

    private val navy = Color.parseColor("#0A1B3D")
    private val blue = Color.parseColor("#17407A")
    private val orange = Color.parseColor("#E8870E")
    private val dim = Color.parseColor("#9FB3D1")
    private val line = Color.parseColor("#CFD8E6")
    private val hot = Color.parseColor("#F5A31A")
    private val green = Color.parseColor("#8BC34A")
    private val perms = arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)

    private val items = ArrayList<Item>()
    private val fileAdapter = FileAdapter()
    private val ui = Handler(Looper.getMainLooper())
    private var showVideo = true
    private var sel = 0
    private val prefs by lazy { getSharedPreferences("pos", MODE_PRIVATE) }
    private var bars: Insets = Insets.NONE

    private lateinit var mainUi: LinearLayout
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var countText: TextView
    private lateinit var menuVideo: TextView
    private lateinit var menuMusic: TextView

    private lateinit var playerLayer: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var banner: LinearLayout
    private lateinit var bannerTitle: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var playBtn: ImageView
    private var player: ExoPlayer? = null
    private var videoRatio = 0f

    private val hideBanner = Runnable { banner.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            player?.let { p ->
                val d = p.duration
                if (d != C.TIME_UNSET && d > 0) {
                    seek.max = d.toInt()
                    seek.progress = p.currentPosition.toInt()
                    timeText.text = "${fmt(p.currentPosition)} / ${fmt(d)}"
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun match() = FrameLayout.LayoutParams(MATCH, MATCH)

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%02d:%02d".format(s / 60, s % 60)
    }

    private fun pill() = GradientDrawable().apply {
        setColor(orange)
        cornerRadius = dp(6).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(buildMain(), match())
        root.addView(buildPlayer(), match())
        root.setOnApplyWindowInsetsListener { _, insets ->
            bars = insets.getInsets(WindowInsets.Type.systemBars())
            applyBars()
            insets
        }
        setContentView(root)
        styleMenu()
        refresh()
    }

    private fun applyBars() {
        mainUi.setPadding(bars.left + dp(24), bars.top + dp(16), bars.right + dp(24), bars.bottom + dp(12))
        banner.setPadding(bars.left + dp(24), dp(14), bars.right + dp(24), bars.bottom + dp(14))
    }

    // ---------- Home screen ----------

    private fun buildMain(): LinearLayout {
        mainUi = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(navy, blue))
        }

        // Clock box, top right, outside the panel
        val clock = TextClock(this).apply {
            format12Hour = "HH:mm"
            format24Hour = "HH:mm"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(4), dp(14), dp(4))
            background = GradientDrawable().apply {
                setColor(navy)
                setStroke(dp(2), line)
                cornerRadius = dp(8).toFloat()
            }
        }
        mainUi.addView(clock, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            gravity = Gravity.END
            bottomMargin = dp(8)
        })

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(2))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0C1530"))
                setStroke(dp(2), line)
                cornerRadius = dp(8).toFloat()
            }
        }

        countText = label("", 12f, dim)
        panel.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addView(label("Box Player", 18f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(countText)
        })
        panel.addView(divider(), LinearLayout.LayoutParams(MATCH, dp(1)))

        menuVideo = tab("VIDEOS") { select(true) }
        menuMusic = tab("MUSIC") { select(false) }
        panel.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(8), dp(6))
            addView(
                label(SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(Date()), 12f, Color.WHITE),
                LinearLayout.LayoutParams(0, WRAP, 1f)
            )
            addView(menuVideo)
            addView(menuMusic)
        })
        panel.addView(divider(), LinearLayout.LayoutParams(MATCH, dp(1)))

        empty = label("No files to show.\nMake sure media access is allowed.", 16f, dim).apply {
            gravity = Gravity.CENTER
        }
        list = ListView(this).apply {
            isFocusable = false
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(2)
            setSelector(ColorDrawable(Color.TRANSPARENT))
            setPadding(dp(2), dp(6), dp(2), dp(6))
            clipToPadding = false
            adapter = fileAdapter
            emptyView = empty
            setOnItemClickListener { _, _, pos, _ -> if (pos == sel) play(pos) else choose(pos) }
        }
        val right = FrameLayout(this).apply {
            addView(list, match())
            addView(empty, match())
        }
        panel.addView(right, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val hints = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1B2A4A"))
                cornerRadius = dp(6).toFloat()
            }
        }
        val grey = Color.parseColor("#9AA5B8")
        hints.addView(hint(grey, "×", "close") { finish() })
        hints.addView(hint(Color.parseColor("#43A047"), "", "videos") { select(true) })
        hints.addView(hint(Color.parseColor("#E53935"), "", "music") { select(false) })
        hints.addView(hint(Color.parseColor("#1E88E5"), "", "play all") { if (items.isNotEmpty()) play(0) })
        hints.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        hints.addView(hint(grey, "OK", "play") { if (items.isNotEmpty()) play(sel) })
        panel.addView(hints, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })

        mainUi.addView(panel, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return mainUi
    }

    private fun divider() = View(this).apply { setBackgroundColor(line) }

    private fun tab(t: String, onClick: () -> Unit) = label(t, 12f, Color.WHITE, true).apply {
        setPadding(dp(12), dp(5), dp(12), dp(5))
        setOnClickListener { onClick() }
    }

    private fun hint(color: Int, glyph: String, text: String, onClick: () -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(4), dp(12), dp(4))
        addView(TextView(context).apply {
            this.text = glyph
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            minWidth = dp(18)
            minHeight = dp(18)
            setPadding(dp(4), 0, dp(4), 0)
            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(9).toFloat()
            }
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(6) })
        addView(label(text, 12f, Color.WHITE))
        setOnClickListener { onClick() }
    }

    private fun styleMenu() {
        for ((v, on) in listOf(menuVideo to showVideo, menuMusic to !showVideo)) {
            v.background = if (on) pill() else null
            v.setTextColor(if (on) Color.BLACK else Color.WHITE)
        }
    }

    private fun select(video: Boolean) {
        showVideo = video
        styleMenu()
        refresh()
    }

    private fun choose(pos: Int) {
        sel = pos
        fileAdapter.notifyDataSetChanged()
        list.post { list.smoothScrollToPosition(pos) }
    }

    // TV-remote style keys: up/down move the highlight, OK plays
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (playerLayer.visibility == View.VISIBLE || items.isEmpty()) return super.onKeyDown(keyCode, event)
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_DOWN -> choose((sel + 1).coerceAtMost(items.lastIndex))
            KeyEvent.KEYCODE_DPAD_UP -> choose((sel - 1).coerceAtLeast(0))
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> play(sel)
            else -> return super.onKeyDown(keyCode, event)
        }
        return true
    }

    // ---------- Library ----------

    private fun hasAccess() = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun refresh() {
        if (!hasAccess()) {
            requestPermissions(perms, 1)
            return
        }
        val video = showVideo
        Thread {
            val found = query(video)
            runOnUiThread {
                items.clear()
                items.addAll(found)
                sel = 0
                countText.text = "${items.size} files"
                fileAdapter.notifyDataSetChanged()
            }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAccess()) refresh()
    }

    private fun size(b: Long) =
        if (b >= (1L shl 30)) "%.1f GB".format(b / 1073741824.0) else "%d MB".format(b shr 20)

    private fun query(video: Boolean): List<Item> {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val nameCol = if (video) MediaStore.Video.Media.DISPLAY_NAME else MediaStore.Audio.Media.TITLE
        val colA = if (video) MediaStore.Video.Media.WIDTH else MediaStore.Audio.Media.ARTIST
        val colB = if (video) MediaStore.Video.Media.HEIGHT else MediaStore.Audio.Media.ALBUM
        val where = if (video) null else "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val out = ArrayList<Item>()
        contentResolver.query(
            base,
            arrayOf(
                MediaStore.MediaColumns._ID, nameCol, MediaStore.MediaColumns.DURATION,
                MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED, colA, colB
            ),
            where, null, "$nameCol COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val raw = c.getString(1) ?: "Untitled"
                val title = if (video) raw.substringBeforeLast('.') else raw
                val dur = c.getLong(2)
                val first = c.getString(5) ?: ""
                val second = c.getString(6) ?: ""
                val info = if (video) {
                    if (first.isNotEmpty() && first != "0") "${first}×${second} · ${fmt(dur)}" else "Video · ${fmt(dur)}"
                } else {
                    val artist = if (first.isEmpty() || first == "<unknown>") "Unknown artist" else first
                    "$artist · ${fmt(dur)}"
                }
                val added = "Added ${dateFmt.format(Date(c.getLong(4) * 1000))} · ${size(c.getLong(3))}"
                out.add(Item(ContentUris.withAppendedId(base, c.getLong(0)), title, dur, info, added))
            }
        }
        return out
    }

    private fun progressOf(item: Item): Int {
        if (item.durationMs <= 0) return 0
        return (prefs.getLong(item.uri.toString(), 0L) * 100 / item.durationMs).toInt().coerceIn(0, 100)
    }

    private fun savePosition() {
        val p = player ?: return
        val item = items.getOrNull(p.currentMediaItemIndex) ?: return
        val pos = p.currentPosition
        val value = if (item.durationMs > 0 && pos > item.durationMs - 5000) 0L else pos
        prefs.edit().putLong(item.uri.toString(), value).apply()
    }

    private fun buildRow() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(14), dp(10))
        addView(LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(label("", 18f, Color.WHITE, true).apply { ellipsize = TextUtils.TruncateAt.END },
                LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(label("", 18f, Color.WHITE, true).apply { gravity = Gravity.END },
                LinearLayout.LayoutParams(dp(48), WRAP))
        })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), 0, 0)
            addView(label("", 14f, Color.WHITE))
            addView(label("", 13f, Color.parseColor("#FFF3E0")).apply { setPadding(0, dp(4), 0, dp(8)) })
            addView(LinearLayout(context).apply {
                weightSum = 100f
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#7A4A00"))
                    cornerRadius = dp(4).toFloat()
                }
                addView(View(context).apply {
                    background = GradientDrawable().apply {
                        setColor(green)
                        cornerRadius = dp(4).toFloat()
                    }
                }, LinearLayout.LayoutParams(0, dp(8), 0f))
                addView(View(context), LinearLayout.LayoutParams(0, dp(8), 0f))
            }, LinearLayout.LayoutParams(MATCH, dp(8)))
        })
    }

    private inner class FileAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: buildRow()
            val item = items[position]
            val on = position == sel
            row.background = GradientDrawable().apply {
                setColor(if (on) hot else orange)
                cornerRadius = dp(3).toFloat()
            }
            val head = row.getChildAt(0) as LinearLayout
            (head.getChildAt(0) as TextView).apply {
                text = item.title
                maxLines = if (on) 2 else 1
            }
            (head.getChildAt(1) as TextView).text = (position + 1).toString()
            val details = row.getChildAt(1) as LinearLayout
            details.visibility = if (on) View.VISIBLE else View.GONE
            if (on) {
                (details.getChildAt(0) as TextView).text = item.line2
                (details.getChildAt(1) as TextView).text = item.line3
                val pct = progressOf(item)
                val bar = details.getChildAt(2) as LinearLayout
                (bar.getChildAt(0).layoutParams as LinearLayout.LayoutParams).weight = pct.toFloat()
                (bar.getChildAt(1).layoutParams as LinearLayout.LayoutParams).weight = (100 - pct).toFloat()
                bar.requestLayout()
            }
            return row
        }
    }

    // ---------- Player ----------

    private fun buildPlayer(): FrameLayout {
        playerLayer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            isClickable = true
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitVideo() }
        }
        surface = SurfaceView(this)
        playerLayer.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        playerLayer.addView(View(this).apply { setOnClickListener { toggleBanner() } }, match())

        bannerTitle = label("", 20f, Color.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        timeText = label("00:00 / 00:00", 14f, dim)
        seek = SeekBar(this).apply {
            progressTintList = ColorStateList.valueOf(orange)
            thumbTintList = ColorStateList.valueOf(orange)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) player?.seekTo(progress.toLong())
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        playBtn = ctrl(android.R.drawable.ic_media_play) {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        val seekRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        seekRow.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        seekRow.addView(timeText)
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(ctrl(android.R.drawable.ic_media_previous) { player?.seekToPreviousMediaItem() })
            addView(ctrl(android.R.drawable.ic_media_rew) { player?.let { it.seekTo(maxOf(0L, it.currentPosition - 10_000)) } })
            addView(playBtn)
            addView(ctrl(android.R.drawable.ic_media_ff) { player?.let { it.seekTo(it.currentPosition + 10_000) } })
            addView(ctrl(android.R.drawable.ic_media_next) { player?.seekToNextMediaItem() })
        }
        banner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xEE0A1B3D.toInt()))
            visibility = View.GONE
            addView(bannerTitle)
            addView(seekRow)
            addView(controls)
        }
        playerLayer.addView(banner, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        return playerLayer
    }

    private fun ctrl(res: Int, onClick: () -> Unit) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(dp(8), 0, dp(8), 0) }
        setOnClickListener {
            onClick()
            showBanner()
        }
    }

    private fun play(index: Int) {
        val p = player ?: ExoPlayer.Builder(this).build().also { np ->
            np.setVideoSurfaceView(surface)
            np.addListener(object : Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = titleFor(np.currentMediaItemIndex)
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playBtn.setImageResource(if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
                }
                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    videoRatio = if (videoSize.height == 0) 0f
                    else videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
                    fitVideo()
                }
            })
            player = np
        }
        surface.visibility = if (showVideo) View.VISIBLE else View.INVISIBLE
        sel = index
        val saved = prefs.getLong(items[index].uri.toString(), 0L)
        val start = if (saved > 0 && saved < items[index].durationMs - 5000) saved else 0L
        p.setMediaItems(items.map { MediaItem.fromUri(it.uri) }, index, start)
        p.prepare()
        p.play()
        playerLayer.visibility = View.VISIBLE
        window.insetsController?.apply {
            hide(WindowInsets.Type.systemBars())
            systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        titleFor(index)
        showBanner()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    private fun titleFor(i: Int) {
        bannerTitle.text = items.getOrNull(i)?.let { "%03d   %s".format(i + 1, it.title) } ?: ""
    }

    private fun fitVideo() {
        val cw = playerLayer.width
        val ch = playerLayer.height
        if (videoRatio <= 0f || cw == 0 || ch == 0) return
        val w: Int
        val h: Int
        if (cw.toFloat() / ch > videoRatio) {
            h = ch
            w = (ch * videoRatio).toInt()
        } else {
            w = cw
            h = (cw / videoRatio).toInt()
        }
        surface.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    private fun showBanner() {
        banner.visibility = View.VISIBLE
        ui.removeCallbacks(hideBanner)
        if (showVideo) ui.postDelayed(hideBanner, 5000)
    }

    private fun toggleBanner() {
        if (banner.visibility == View.VISIBLE) {
            ui.removeCallbacks(hideBanner)
            banner.visibility = View.GONE
        } else showBanner()
    }

    private fun closePlayer() {
        ui.removeCallbacks(tick)
        ui.removeCallbacks(hideBanner)
        savePosition()
        player?.let { sel = it.currentMediaItemIndex }
        player?.release()
        player = null
        playerLayer.visibility = View.GONE
        fileAdapter.notifyDataSetChanged()
        window.insetsController?.show(WindowInsets.Type.systemBars())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (playerLayer.visibility == View.VISIBLE) closePlayer() else super.onBackPressed()
    }

    override fun onStop() {
        super.onStop()
        savePosition()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        player?.release()
        player = null
    }
}
