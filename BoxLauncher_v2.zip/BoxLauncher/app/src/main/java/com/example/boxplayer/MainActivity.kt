package com.example.boxplayer

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Insets
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Original set-top-box style media player: navy gradient, left menu,
 * numbered file list, colour-button hint bar and an on-screen info banner.
 */
class MainActivity : Activity() {

    private data class Item(
        val uri: android.net.Uri,
        val title: String,
        val durationMs: Long,
        val line2: String,
        val line3: String
    )

    private val navy = Color.parseColor("#0A1B3D")
    private val blue = Color.parseColor("#17407A")
    private val orange = Color.parseColor("#F7931D")
    private val dim = Color.parseColor("#9FB3D1")
    private val line = Color.parseColor("#CFD8E6")
    private val hot = Color.parseColor("#F5A31A")
    private val green = Color.parseColor("#8BC34A")
    private val perms = arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)

    private val items = ArrayList<Item>()
    private val fileAdapter = FileAdapter()
    private val ui = Handler(Looper.getMainLooper())
    private var showVideo = true
    private var sel = 0
    private val prefs by lazy { getSharedPreferences("pos", MODE_PRIVATE) }
    private var bars: Insets = Insets.NONE

    private lateinit var mainUi: LinearLayout
    private lateinit var list: GridView
    private lateinit var empty: TextView
    private lateinit var countText: TextView
    private lateinit var menuVideo: LinearLayout
    private lateinit var menuMusic: LinearLayout

    private lateinit var playerLayer: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var banner: LinearLayout
    private lateinit var bannerTitle: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var playBtn: ImageView
    private var player: ExoPlayer? = null
    private var videoRatio = 0f

    private val hideBanner = Runnable { banner.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            player?.let { p ->
                val d = p.duration
                if (d != C.TIME_UNSET && d > 0) {
                    seek.max = d.toInt()
                    seek.progress = p.currentPosition.toInt()
                    timeText.text = "${fmt(p.currentPosition)} / ${fmt(d)}"
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun match() = FrameLayout.LayoutParams(MATCH, MATCH)

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%02d:%02d".format(s / 60, s % 60)
    }

    private fun pill() = GradientDrawable().apply {
        setColor(orange)
        cornerRadius = dp(6).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(buildMain(), match())
        root.addView(buildPlayer(), match())
        root.setOnApplyWindowInsetsListener { _, insets ->
            bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            applyBars()
            insets
        }
        setContentView(root)
        styleMenu()
        refresh()
    }

    private fun applyBars() {
        mainUi.setPadding(bars.left + dp(16), bars.top + dp(6), bars.right + dp(16), bars.bottom + dp(8))
        banner.setPadding(bars.left + dp(24), dp(14), bars.right + dp(24), bars.bottom + dp(14))
    }

    // ---------- Home screen: dark tile layout ----------

    private val isPl = Locale.getDefault().language == "pl"
    private val cardBg = Color.parseColor("#38393D")
    private val muted = Color.parseColor("#A0A3A8")
    private val thumbs = LruCache<String, Bitmap>(80)
    private val pool: ExecutorService = Executors.newFixedThreadPool(3)
    private var showApps = true   // a launcher opens on its apps
    private lateinit var menuApps: LinearLayout
    private lateinit var infoTitle: TextView
    private lateinit var infoSub: TextView

    private fun t(en: String, pl: String) = if (isPl) pl else en
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    private fun rounded(c: Int, r: Int = 3) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = dp(r).toFloat()
    }

    private fun buildMain(): LinearLayout {
        mainUi = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#2E2F32"), Color.parseColor("#1A1B1E"))
            )
        }
        menuApps = tab(t("APPS", "APLIKACJE")) { selectApps() }
        menuVideo = tab(t("VIDEOS", "WIDEO")) { select(true) }
        menuMusic = tab(t("MUSIC", "MUZYKA")) { select(false) }

        // Top bar: title, tabs with orange underline, date and clock
        val dateText = SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date())
        mainUi.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(label("Box Launcher", 18f, Color.WHITE, true).apply { setPadding(0, 0, dp(24), 0) })
            addView(menuApps)
            addView(menuVideo)
            addView(menuMusic)
            addView(View(context), lp(0, 1, 1f))
            addView(label(dateText, 12f, muted).apply { setPadding(0, 0, dp(12), 0) })
            addView(TextClock(context).apply {
                format12Hour = "HH:mm"
                format24Hour = "HH:mm"
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            })
        }, lp(MATCH, WRAP).apply { bottomMargin = dp(6) })

        // Tile grid
        empty = label(
            t("Nothing to show.\nMake sure media access is allowed.", "Brak elementów.\nSprawdź dostęp do multimediów."),
            14f, muted
        ).apply { gravity = Gravity.CENTER }
        list = GridView(this).apply {
            numColumns = GridView.AUTO_FIT
            columnWidth = dp(150)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            horizontalSpacing = dp(10)
            verticalSpacing = dp(10)
            isFocusable = false
            setSelector(ColorDrawable(Color.TRANSPARENT))
            setPadding(dp(2), dp(6), dp(2), dp(6))
            clipToPadding = false
            adapter = fileAdapter
            emptyView = empty
            setOnItemClickListener { _, _, pos, _ -> if (pos == sel) activate(pos) else choose(pos) }
            setOnItemLongClickListener { _, _, pos, _ ->
                if (showApps) {
                    appInfo(pos)
                    true
                } else false
            }
        }
        mainUi.addView(FrameLayout(this).apply {
            addView(list, match())
            addView(empty, match())
        }, lp(MATCH, 0, 1f))

        // Info bar for the selected tile
        infoTitle = label("", 15f, Color.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        infoSub = label("", 12f, muted).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        countText = label("", 12f, muted).apply { setPadding(dp(12), 0, dp(12), 0) }
        mainUi.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rounded(Color.parseColor("#2A2B2F"), 10)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(infoTitle)
                addView(infoSub)
            }, lp(0, WRAP, 1f))
            addView(countText)
            addView(label("OK", 11f, Color.BLACK, true).apply {
                setPadding(dp(8), dp(2), dp(8), dp(2))
                background = rounded(orange, 10)
            })
            addView(label(t("open", "otwórz"), 12f, muted).apply { setPadding(dp(6), 0, 0, 0) })
        }, lp(MATCH, WRAP).apply { topMargin = dp(6) })
        return mainUi
    }

    private fun tab(txt: String, onClick: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(10), dp(4), dp(10), 0)
        addView(label(txt, 13f, muted, true))
        addView(View(context).apply { setBackgroundColor(orange) }, lp(MATCH, dp(3)).apply { topMargin = dp(3) })
        setOnClickListener { onClick() }
    }

    private fun styleMenu() {
        for ((v, on) in listOf(
            menuApps to showApps,
            menuVideo to (!showApps && showVideo),
            menuMusic to (!showApps && !showVideo)
        )) {
            (v.getChildAt(0) as TextView).setTextColor(if (on) Color.WHITE else muted)
            v.getChildAt(1).visibility = if (on) View.VISIBLE else View.INVISIBLE
        }
    }

    private fun resetList() {
        items.clear()
        sel = 0
        countText.text = ""
        fileAdapter.notifyDataSetChanged()
        updateInfo()
    }

    private fun select(video: Boolean) {
        showApps = false
        showVideo = video
        resetList()
        styleMenu()
        refresh()
    }

    private fun selectApps() {
        showApps = true
        resetList()
        styleMenu()
        refresh()
    }

    private fun choose(pos: Int) {
        sel = pos
        fileAdapter.notifyDataSetChanged()
        updateInfo()
        list.post { list.smoothScrollToPosition(pos) }
    }

    private fun updateInfo() {
        val item = items.getOrNull(sel)
        infoTitle.text = item?.title ?: ""
        infoSub.text = if (item == null) "" else "${item.line2} · ${item.line3}"
    }

    // TV-remote style keys: arrows move the highlight, OK opens
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (playerLayer.visibility == View.VISIBLE || items.isEmpty()) return super.onKeyDown(keyCode, event)
        val cols = maxOf(1, list.numColumns)
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> choose((sel + 1).coerceAtMost(items.lastIndex))
            KeyEvent.KEYCODE_DPAD_LEFT -> choose((sel - 1).coerceAtLeast(0))
            KeyEvent.KEYCODE_DPAD_DOWN -> choose((sel + cols).coerceAtMost(items.lastIndex))
            KeyEvent.KEYCODE_DPAD_UP -> choose((sel - cols).coerceAtLeast(0))
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> activate(sel)
            else -> return super.onKeyDown(keyCode, event)
        }
        return true
    }

    // ---------- Launcher ----------

    private fun activate(pos: Int) {
        if (showApps) launchApp(pos) else play(pos)
    }

    private fun launchApp(pos: Int) {
        val parts = items.getOrNull(pos)?.uri?.schemeSpecificPart?.split("/", limit = 2) ?: return
        if (parts.size < 2) return
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(parts[0], parts[1])
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (_: Exception) {
        }
    }

    // Long-press an app tile: opens its system info page (uninstall, permissions...)
    private fun appInfo(pos: Int) {
        val pkg = items.getOrNull(pos)?.uri?.schemeSpecificPart?.substringBefore('/') ?: return
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    private fun appIcon(item: Item): android.graphics.drawable.Drawable? {
        val parts = item.uri.schemeSpecificPart?.split("/", limit = 2) ?: return null
        if (parts.size < 2) return null
        return try {
            packageManager.getActivityIcon(ComponentName(parts[0], parts[1]))
        } catch (_: Exception) {
            null
        }
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        Thread {
            val pm = packageManager
            val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val found = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { it to it.loadLabel(pm).toString() }
                .sortedBy { it.second.lowercase() }
                .map { (ri, name) ->
                    val a = ri.activityInfo
                    val pi = try {
                        pm.getPackageInfo(a.packageName, 0)
                    } catch (_: Exception) {
                        null
                    }
                    val version = pi?.versionName ?: "?"
                    val installed = pi?.let { dateFmt.format(Date(it.firstInstallTime)) } ?: "?"
                    Item(
                        Uri.fromParts("app", "${a.packageName}/${a.name}", null),
                        name, 0L, a.packageName,
                        "${t("Version", "Wersja")} $version · ${t("Installed", "Zainstalowano")} $installed"
                    )
                }
            runOnUiThread {
                if (!showApps) return@runOnUiThread
                items.clear()
                items.addAll(found)
                sel = 0
                countText.text = "${items.size} " + t("apps", "aplikacji")
                fileAdapter.notifyDataSetChanged()
                updateInfo()
            }
        }.start()
    }

    // ---------- Library ----------

    private fun hasAccess() = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun refresh() {
        if (showApps) {
            loadApps()
            return
        }
        if (!hasAccess()) {
            requestPermissions(perms, 1)
            return
        }
        val video = showVideo
        Thread {
            val found = query(video)
            runOnUiThread {
                if (showApps || showVideo != video) return@runOnUiThread
                items.clear()
                items.addAll(found)
                sel = 0
                countText.text = "${items.size} " + t("files", "plików")
                fileAdapter.notifyDataSetChanged()
                updateInfo()
            }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAccess()) refresh()
    }

    private fun size(b: Long) =
        if (b >= (1L shl 30)) "%.1f GB".format(b / 1073741824.0) else "%d MB".format(b shr 20)

    private fun query(video: Boolean): List<Item> {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val nameCol = if (video) MediaStore.Video.Media.DISPLAY_NAME else MediaStore.Audio.Media.TITLE
        val colA = if (video) MediaStore.Video.Media.WIDTH else MediaStore.Audio.Media.ARTIST
        val colB = if (video) MediaStore.Video.Media.HEIGHT else MediaStore.Audio.Media.ALBUM
        val where = if (video) null else "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val out = ArrayList<Item>()
        contentResolver.query(
            base,
            arrayOf(
                MediaStore.MediaColumns._ID, nameCol, MediaStore.MediaColumns.DURATION,
                MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED, colA, colB
            ),
            where, null, "$nameCol COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val raw = c.getString(1) ?: "Untitled"
                val title = if (video) raw.substringBeforeLast('.') else raw
                val dur = c.getLong(2)
                val first = c.getString(5) ?: ""
                val second = c.getString(6) ?: ""
                val info = if (video) {
                    if (first.isNotEmpty() && first != "0") "${first}×${second} · ${fmt(dur)}"
                    else "${t("Video", "Wideo")} · ${fmt(dur)}"
                } else {
                    val artist = if (first.isEmpty() || first == "<unknown>") t("Unknown artist", "Nieznany wykonawca") else first
                    "$artist · ${fmt(dur)}"
                }
                val added = "${t("Added", "Dodano")} ${dateFmt.format(Date(c.getLong(4) * 1000))} · ${size(c.getLong(3))}"
                out.add(Item(ContentUris.withAppendedId(base, c.getLong(0)), title, dur, info, added))
            }
        }
        return out
    }

    private fun progressOf(item: Item): Int {
        if (item.durationMs <= 0) return 0
        return (prefs.getLong(item.uri.toString(), 0L) * 100 / item.durationMs).toInt().coerceIn(0, 100)
    }

    private fun savePosition() {
        val p = player ?: return
        val item = items.getOrNull(p.currentMediaItemIndex) ?: return
        val pos = p.currentPosition
        val value = if (item.durationMs > 0 && pos > item.durationMs - 5000) 0L else pos
        prefs.edit().putLong(item.uri.toString(), value).apply()
    }

    // ---------- Tiles ----------

    private fun buildTile() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(3), dp(3), dp(3), dp(3))
        addView(FrameLayout(context).apply {
            background = rounded(cardBg, 8)
            clipToOutline = true
            addView(ImageView(context), FrameLayout.LayoutParams(MATCH, MATCH))
            addView(label("", 10f, Color.WHITE, true).apply {
                setPadding(dp(5), dp(1), dp(5), dp(1))
                background = rounded(Color.parseColor("#CC000000"), 4)
            }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.BOTTOM).apply {
                setMargins(0, 0, dp(5), dp(8))
            })
            addView(LinearLayout(context).apply {
                weightSum = 100f
                setBackgroundColor(Color.parseColor("#66000000"))
                addView(View(context).apply { setBackgroundColor(orange) }, lp(0, MATCH, 0f))
                addView(View(context), lp(0, MATCH, 0f))
            }, FrameLayout.LayoutParams(MATCH, dp(3), Gravity.BOTTOM))
        }, lp(MATCH, dp(86)))
        addView(label("", 13f, Color.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(2), dp(5), dp(2), 0)
        })
        addView(label("", 11f, muted).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(2), 0, dp(2), dp(2))
        })
    }

    private fun loadThumb(item: Item, target: ImageView) {
        val key = item.uri.toString()
        target.tag = key
        val cached = thumbs.get(key)
        if (cached != null) {
            target.setImageBitmap(cached)
            return
        }
        target.setImageDrawable(null)
        pool.execute {
            val bmp = try {
                contentResolver.loadThumbnail(item.uri, Size(320, 180), null)
            } catch (_: Exception) {
                null
            }
            if (bmp != null) thumbs.put(key, bmp)
            runOnUiThread {
                if (target.tag != key) return@runOnUiThread
                if (bmp != null) {
                    target.setImageBitmap(bmp)
                } else {
                    target.scaleType = ImageView.ScaleType.CENTER
                    target.alpha = 0.35f
                    target.setImageResource(android.R.drawable.ic_media_play)
                }
            }
        }
    }

    private inner class FileAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val tile = (convertView as? LinearLayout) ?: buildTile()
            val item = items[position]
            tile.background = if (position == sel) rounded(orange, 11) else null

            val card = tile.getChildAt(0) as FrameLayout
            val img = card.getChildAt(0) as ImageView
            val badge = card.getChildAt(1) as TextView
            val bar = card.getChildAt(2) as LinearLayout
            (tile.getChildAt(1) as TextView).text = item.title
            val sub = tile.getChildAt(2) as TextView

            img.alpha = 1f
            if (showApps) {
                img.tag = null
                img.scaleType = ImageView.ScaleType.FIT_CENTER
                img.setPadding(dp(22), dp(14), dp(22), dp(14))
                img.setImageDrawable(appIcon(item))
                badge.visibility = View.GONE
                bar.visibility = View.GONE
                sub.visibility = View.GONE
            } else {
                img.scaleType = ImageView.ScaleType.CENTER_CROP
                img.setPadding(0, 0, 0, 0)
                loadThumb(item, img)
                badge.visibility = if (item.durationMs > 0) View.VISIBLE else View.GONE
                badge.text = fmt(item.durationMs)
                val pct = progressOf(item)
                bar.visibility = if (pct > 0) View.VISIBLE else View.GONE
                (bar.getChildAt(0).layoutParams as LinearLayout.LayoutParams).weight = pct.toFloat()
                (bar.getChildAt(1).layoutParams as LinearLayout.LayoutParams).weight = (100 - pct).toFloat()
                bar.requestLayout()
                sub.visibility = View.VISIBLE
                sub.text = item.line2
            }
            return tile
        }
    }

    // ---------- Player ----------

    private fun buildPlayer(): FrameLayout {
        playerLayer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            isClickable = true
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitVideo() }
        }
        surface = SurfaceView(this)
        playerLayer.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        playerLayer.addView(View(this).apply { setOnClickListener { toggleBanner() } }, match())

        bannerTitle = label("", 20f, Color.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        timeText = label("00:00 / 00:00", 14f, dim)
        seek = SeekBar(this).apply {
            progressTintList = ColorStateList.valueOf(orange)
            thumbTintList = ColorStateList.valueOf(orange)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) player?.seekTo(progress.toLong())
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        playBtn = ctrl(android.R.drawable.ic_media_play) {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        val seekRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        seekRow.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        seekRow.addView(timeText)
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(ctrl(android.R.drawable.ic_media_previous) { player?.seekToPreviousMediaItem() })
            addView(ctrl(android.R.drawable.ic_media_rew) { player?.let { it.seekTo(maxOf(0L, it.currentPosition - 10_000)) } })
            addView(playBtn)
            addView(ctrl(android.R.drawable.ic_media_ff) { player?.let { it.seekTo(it.currentPosition + 10_000) } })
            addView(ctrl(android.R.drawable.ic_media_next) { player?.seekToNextMediaItem() })
        }
        banner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xEE1A1B1E.toInt()))
            visibility = View.GONE
            addView(bannerTitle)
            addView(seekRow)
            addView(controls)
        }
        playerLayer.addView(banner, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        return playerLayer
    }

    private fun ctrl(res: Int, onClick: () -> Unit) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(dp(8), 0, dp(8), 0) }
        setOnClickListener {
            onClick()
            showBanner()
        }
    }

    private fun play(index: Int) {
        val p = player ?: ExoPlayer.Builder(this).build().also { np ->
            np.setVideoSurfaceView(surface)
            np.addListener(object : Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = titleFor(np.currentMediaItemIndex)
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playBtn.setImageResource(if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
                }
                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    videoRatio = if (videoSize.height == 0) 0f
                    else videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
                    fitVideo()
                }
            })
            player = np
        }
        surface.visibility = if (showVideo) View.VISIBLE else View.INVISIBLE
        sel = index
        val saved = prefs.getLong(items[index].uri.toString(), 0L)
        val start = if (saved > 0 && saved < items[index].durationMs - 5000) saved else 0L
        p.setMediaItems(items.map { MediaItem.fromUri(it.uri) }, index, start)
        p.prepare()
        p.play()
        playerLayer.visibility = View.VISIBLE
        window.insetsController?.apply {
            hide(WindowInsets.Type.systemBars())
            systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        titleFor(index)
        showBanner()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    private fun titleFor(i: Int) {
        bannerTitle.text = items.getOrNull(i)?.let { "%03d   %s".format(i + 1, it.title) } ?: ""
    }

    private fun fitVideo() {
        val cw = playerLayer.width
        val ch = playerLayer.height
        if (videoRatio <= 0f || cw == 0 || ch == 0) return
        val w: Int
        val h: Int
        if (cw.toFloat() / ch > videoRatio) {
            h = ch
            w = (ch * videoRatio).toInt()
        } else {
            w = cw
            h = (cw / videoRatio).toInt()
        }
        surface.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    private fun showBanner() {
        banner.visibility = View.VISIBLE
        ui.removeCallbacks(hideBanner)
        if (showVideo) ui.postDelayed(hideBanner, 5000)
    }

    private fun toggleBanner() {
        if (banner.visibility == View.VISIBLE) {
            ui.removeCallbacks(hideBanner)
            banner.visibility = View.GONE
        } else showBanner()
    }

    private fun closePlayer() {
        ui.removeCallbacks(tick)
        ui.removeCallbacks(hideBanner)
        savePosition()
        player?.let { sel = it.currentMediaItemIndex }
        player?.release()
        player = null
        playerLayer.visibility = View.GONE
        fileAdapter.notifyDataSetChanged()
        updateInfo()
        window.insetsController?.show(WindowInsets.Type.systemBars())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (playerLayer.visibility == View.VISIBLE) closePlayer() else if (!showApps) selectApps()
    }

    // Pressing Home again closes the player / returns to the apps list
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (playerLayer.visibility == View.VISIBLE) closePlayer() else if (!showApps) selectApps()
    }

    override fun onStop() {
        super.onStop()
        savePosition()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        player?.release()
        player = null
    }
}
